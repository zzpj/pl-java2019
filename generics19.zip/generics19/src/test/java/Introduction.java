import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Introduction {

    @Test
    public void legacyCode() {

        List list = new ArrayList();
        list.add(1l);
        list.add(true);
        list.add("Hello");


        //Integer i = (Integer) list.get(0);

        boolean b = (boolean) list.get(2);
    }

    @Test
    public void genericVersion() {

        List<String> list = new ArrayList<>();
        list.add("String");
        String s = list.get(0);
    }

    @Test
    public void noPrimitives() {

        //you can't use primitive with generics
    //    List<int> ints = null;
      //  List<float> floats = new ArrayList<>();

    }

    @Test
    public void boxingUnboxing() {

        List<Long> ints = new ArrayList<>();

        ints.add(30l);

        Long aLong = ints.get(0);
        int i = aLong.intValue();
        long l = aLong.longValue();

        Long aLong1 = Long.valueOf(5l);

    }

    @Test
    public void typeDeduction() {

        List<Integer> integers = Arrays.asList(1, 2, 3, 4, 5, 6);
        List<Integer> collect = Stream.of(5, 6, 7, 8, 9, 10).collect(Collectors.toList());
        Set<? extends Number> numbers = Stream.of(5, 4, 3, 2, 6.3, 400l).collect(Collectors.toSet());




    }
}