import org.junit.Test;

import java.util.*;

import static java.util.stream.Collectors.*;

public class SubtypingAndSubstitution {


    @Test
    public void substitutionPrinciple() {

        List<Person> people = new ArrayList<>();
        people.add(new Student(1, "Henry", 1234L));
        people.add(new Employee(2, "Anna", "e-1", 100.0d));

        System.out.println(people);

    }

    @Test
    public void substitutionPrincipleWithInheritance_case1() {


        List<Student> students = getStudents();
        //List<Person> people = students;

    }


    @Test
    public void substitutionPrincipleWithInheritance_case2() {


        List<Person> people = getPeople();
        List<Student> students = getStudents();

        //students = people;
    }

    @Test
    public void wildcardExtends() {

        List<Person> people = getPeople();
        List<Student> students = getStudents();

        people.addAll(students);

        //   students.addAll(people);
    }

    @Test
    public void wildcardSuper() {

        List<Student> students = getStudents();

        List<? extends Person> people = students;
        //    people.add(new Employee(1, "w", "e1", 40d));


        List<Person> people2 = getPeople();
        List<? super Student> p = people2;
        //p.add(new Person(1, "s"));
    }


    @Test
    public void getAndPutPrinciple_case1() {

        PersonService ps = new PersonService();

        List<Person> people = getPeople();

        List<Student> students = getStudents();
        people.addAll(students);

        List<Employee> employees = getEmployees();
        people.addAll(employees);

        Map<String, ? extends List<? extends Person>> stringMap = ps.groupByName(people);
        System.out.println(stringMap);
    }

    @Test
    public void getAndPutPrinciple_case2() {

        PersonService ps = new PersonService();

        List<Person> people = getPeople();

        List<Student> students = getStudents();
        people.addAll(students);

        List<Employee> employees = getEmployees();
        people.addAll(employees);

        ps.addSomething(people);
       // ps.addSomething(employees);
        //ps.addSomething(students);

    }

//------------------------
    class Person {
        Integer id;
        String name;

        public Person(Integer id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return "Person{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    '}';
        }
    }

    class Employee extends Person {
        String employeeId;
        Double salary;

        public Employee(Integer id, String name, String employeeId, Double salary) {
            super(id, name);
            this.employeeId = employeeId;
            this.salary = salary;
        }

        @Override
        public String toString() {
            return "Employee{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    ", employeeId='" + employeeId + '\'' +
                    ", salary=" + salary +
                    '}';
        }
    }

    class Student extends Person {
        Long indexNumber;

        public Student(Integer id, String name, Long indexNumber) {
            super(id, name);
            this.indexNumber = indexNumber;
        }

        @Override
        public String toString() {
            return "Student{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    ", indexNumber=" + indexNumber +
                    '}';
        }
    }

    private List<Person> getPeople() {
        List<Person> people = new ArrayList<>();
        people.add(new Person(1, "Anna"));
        people.add(new Person(2, "Henry"));
        people.add(new Person(3, "Mihai"));

        return people;
    }

    private List<Student> getStudents() {
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Anna", 200L));
        students.add(new Student(2, "Henry", 300L));
        students.add(new Student(3, "Viola", 1200L));
        students.add(new Student(4, "Katrine", 2200L));
        return  students;
    }

    private List<Employee> getEmployees() {

        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(20, "Janusz", "W123", 400.0d));
        return employees;
    }

    class PersonService {

        public Map<String, ? extends List<? extends Person>> groupByName(List<? extends Person> people) {

            return people.stream().collect(groupingBy(p -> p.name, toList()));
        }

        public List<? super Person> addSomething(List<? super Person> people) {
            people.add(new Person(2, "s"));
            people.add(new Employee(1,"d","d", 30d));
            return people;
        }
    }
}
