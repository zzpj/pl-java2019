package pl.ttpsc.microservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.Serializable;
import java.util.List;

@SpringBootApplication
@EnableDiscoveryClient
public class AccountsMicroserviceServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AccountsMicroserviceServerApplication.class, args);
    }
}

@RestController
class AccountController {

    @Autowired
    AccountRepository accountRepository;

    @RequestMapping("/accounts")
    public Account[] getAllAccounts() {
        List<Account> accounts = accountRepository.getAllAccounts();
        return accounts.toArray(new Account[accounts.size()]);
    }

    @RequestMapping("/accounts/{id}")
    public Account getAccountById(@PathVariable("id") String id) {

        Account account = accountRepository.getAccount(id);

        return account;
    }
}

class Account implements Serializable {

    private Long amount;
    private String number;
    private String name;

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Account [amount=" + amount + ", number=" + number + ", name=" + name + "]";
    }

    public Account(Long amount, String name, String number) {
        super();
        this.amount = amount;
        this.number = number;
        this.name = name;
    }

}
