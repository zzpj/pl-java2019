package pl.ttpsc.microservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class AccountRepository {
	
	private Map<String, Account> accountsByNumber = new HashMap<>();
	
	public AccountRepository() {
		Account account = new Account(1000l, "Pablo" , "51215");
		accountsByNumber.put("123456", account);
		account = new Account(2000l, "Frank" , "289");
		accountsByNumber.put("456789", account);
		account = new Account(3000l, "Sophia" , "10286");
		accountsByNumber.put("34567", account);

	}

	public List<Account> getAllAccounts() {
		return new ArrayList<>(accountsByNumber.values());
	}


	public Account getAccount(String number) {
		return accountsByNumber.get(number);
	}

}
